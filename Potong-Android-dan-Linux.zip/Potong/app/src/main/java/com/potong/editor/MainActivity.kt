package com.potong.editor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.potong.editor.ui.editor.EditorScreen
import com.potong.editor.ui.home.HomeScreen
import com.potong.editor.ui.theme.Bg
import com.potong.editor.ui.theme.PotongTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PotongTheme {
                Surface(Modifier.fillMaxSize(), color = Bg) {
                    val nav = rememberNavController()
                    NavHost(nav, startDestination = "home") {
                        composable("home") { HomeScreen { id -> nav.navigate("editor/$id") } }
                        composable("editor/{id}") { e ->
                            EditorScreen(e.arguments?.getString("id") ?: "", onBack = { nav.popBackStack() })
                        }
                    }
                }
            }
        }
    }
}
