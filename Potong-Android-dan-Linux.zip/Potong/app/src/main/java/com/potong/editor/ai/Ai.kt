package com.potong.editor.ai

import com.potong.editor.data.COLORS
import com.potong.editor.data.FILTERS
import com.potong.editor.data.SHAPES
import org.json.JSONArray

/** Perintah yang bisa dijalankan asisten di editor. */
sealed class Cmd {
    object Split : Cmd()
    object DeleteClip : Cmd()
    object Undo : Cmd()
    object Redo : Cmd()
    data class Speed(val v: Float) : Cmd()
    data class Volume(val v: Float) : Cmd()
    data class Filter(val name: String, val all: Boolean = false) : Cmd()
    data class AddText(val text: String) : Cmd()
    data class Add3D(val shape: String, val color: Long) : Cmd()
    data class FindMusic(val query: String) : Cmd()
    data class FindStock(val query: String) : Cmd()
    data class Say(val text: String) : Cmd()
}

/** Antarmuka mesin LLM lokal (mis. Qwen GGUF lewat llama.cpp). Sambungkan implementasinya di sini. */
interface LlmEngine {
    val ready: Boolean
    suspend fun generate(prompt: String): String
}

object NoEngine : LlmEngine {
    override val ready = false
    override suspend fun generate(prompt: String) = ""
}

class AiAssistant(var engine: LlmEngine = NoEngine) {
    suspend fun handle(text: String): List<Cmd> {
        if (engine.ready) {
            val out = runCatching { engine.generate(chatMl(text)) }.getOrDefault("")
            val cmds = parseActions(out)
            if (cmds.isNotEmpty()) return cmds
        }
        return RuleParser.parse(text)   // cadangan offline tanpa model
    }

    private fun chatMl(user: String) =
        "<|im_start|>system\n$SYSTEM<|im_end|>\n<|im_start|>user\n$user<|im_end|>\n<|im_start|>assistant\n"

    fun parseActions(raw: String): List<Cmd> = runCatching {
        val a = JSONArray(raw.substring(raw.indexOf('['), raw.lastIndexOf(']') + 1))
        (0 until a.length()).mapNotNull { i ->
            val o = a.getJSONObject(i)
            when (o.getString("a")) {
                "split" -> Cmd.Split
                "delete" -> Cmd.DeleteClip
                "undo" -> Cmd.Undo
                "redo" -> Cmd.Redo
                "speed" -> Cmd.Speed(o.getDouble("v").toFloat())
                "volume" -> Cmd.Volume(o.getDouble("v").toFloat())
                "filter" -> Cmd.Filter(o.getString("name"), o.optBoolean("all"))
                "text" -> Cmd.AddText(o.getString("text"))
                "obj3d" -> Cmd.Add3D(o.optString("shape", "kubus"), COLORS[o.optString("color")] ?: 0xFF00BFA5L)
                "music" -> Cmd.FindMusic(o.optString("q"))
                "stock" -> Cmd.FindStock(o.optString("q"))
                "say" -> Cmd.Say(o.getString("text"))
                else -> null
            }
        }
    }.getOrDefault(emptyList())

    companion object {
        const val SYSTEM = "Kamu asisten editor video. Balas HANYA array JSON berisi aksi, tanpa teks lain. " +
            "Aksi: {\"a\":\"split\"} {\"a\":\"delete\"} {\"a\":\"undo\"} {\"a\":\"redo\"} " +
            "{\"a\":\"speed\",\"v\":2} {\"a\":\"volume\",\"v\":0.5} {\"a\":\"filter\",\"name\":\"Hitam putih\",\"all\":false} " +
            "{\"a\":\"text\",\"text\":\"isi\"} {\"a\":\"obj3d\",\"shape\":\"kubus\",\"color\":\"merah\"} " +
            "{\"a\":\"music\",\"q\":\"santai\"} {\"a\":\"stock\",\"q\":\"pantai\"} {\"a\":\"say\",\"text\":\"jawaban\"}. " +
            "Filter: Normal, Hitam putih, Cerah, Hangat, Dingin, Drama, Pudar, Terang. Bentuk 3D: kubus, piramida, prisma, bola."
    }
}

/** Pemahaman perintah bahasa Indonesia tanpa model, supaya asisten tetap berguna sebelum Qwen terpasang. */
object RuleParser {
    private val num = Regex("(\\d+(?:[.,]\\d+)?)\\s*(?:x|kali)")
    private val noise = Regex("\\b(cari|carikan|tambah|tambahkan|pasang|musik|lagu|backsound|bgm|video|stok|stock|pixabay|untuk|yang|dong|tolong|dengan|tema)\\b")

    fun parse(raw: String): List<Cmd> {
        val t = raw.trim()
        val l = t.lowercase()
        val out = mutableListOf<Cmd>()
        fun has(vararg w: String) = w.any { l.contains(it) }

        if (has("urung", "undo")) out += Cmd.Undo
        if (has("ulangi", "redo")) out += Cmd.Redo
        if (has("pisah", "belah", "split")) out += Cmd.Split
        if (has("hapus klip", "buang klip")) out += Cmd.DeleteClip
        if (has("bisukan", "mute", "senyap")) out += Cmd.Volume(0f)

        val m = num.find(l)
        if (m != null && has("cepat", "lambat", "kecepatan", "speed")) {
            out += Cmd.Speed(m.groupValues[1].replace(',', '.').toFloat())
        } else if (has("percepat")) {
            out += Cmd.Speed(2f)
        } else if (has("perlambat", "slow")) {
            out += Cmd.Speed(0.5f)
        }

        if (has("tanpa filter", "filter normal")) out += Cmd.Filter("Normal", has("semua"))
        FILTERS.firstOrNull { it != "Normal" && l.contains(it.lowercase()) }
            ?.let { out += Cmd.Filter(it, has("semua")) }

        if (has("teks", "judul") && has("tambah", "buat", "pasang", "tulis")) {
            val body = Regex("(?:teks|judul)\\s*[:\"“]?\\s*(.+)", RegexOption.IGNORE_CASE).find(t)
                ?.groupValues?.get(1)?.trim()?.trim('"', '”', '“').orEmpty()
            out += if (body.isNotBlank()) Cmd.AddText(body) else Cmd.Say("Teksnya apa? Contoh: tambah teks Liburan Bali")
        }

        val shape = SHAPES.firstOrNull { l.contains(it.take(5)) }
        if (shape != null && has("tambah", "buat", "bikin", "pasang", "3d")) {
            val color = COLORS.entries.firstOrNull { l.contains(it.key) }?.value ?: 0xFF00BFA5L
            out += Cmd.Add3D(shape, color)
        }

        if (has("musik", "lagu", "backsound", "bgm") && has("cari", "tambah", "pasang", "butuh", "mau")) {
            out += Cmd.FindMusic(l.replace(noise, " ").trim().replace(Regex("\\s+"), " "))
        }
        if (has("cari video", "video stok", "stok video", "video pixabay")) {
            out += Cmd.FindStock(l.replace(noise, " ").trim().replace(Regex("\\s+"), " "))
        }

        if (out.isEmpty()) out += Cmd.Say(
            "Belum paham. Coba: \"pisah di sini\", \"hitam putih\", \"percepat 2x\", " +
                "\"tambah teks Halo\", \"tambah kubus merah\", \"cari musik santai\", \"cari video pantai\"."
        )
        return out
    }
}
