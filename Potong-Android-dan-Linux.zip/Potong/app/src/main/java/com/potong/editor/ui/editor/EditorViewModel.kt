@file:OptIn(UnstableApi::class)

package com.potong.editor.ui.editor

import android.app.Application
import com.potong.editor.ai.Agent
import com.potong.editor.ai.LlamaEngine
import com.potong.editor.ai.ToolHost
import org.json.JSONArray
import org.json.JSONObject
import android.content.ContentValues
import android.content.Intent
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbAdjustment
import androidx.media3.effect.RgbFilter
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import com.potong.editor.ai.AiAssistant
import com.potong.editor.ai.Cmd
import com.potong.editor.data.*
import com.potong.editor.net.Pixabay
import com.potong.editor.net.StockVideo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class Msg(val user: Boolean, val text: String)

fun effectsFor(f: String): List<Effect> = when (f) {
    "Hitam putih" -> listOf(RgbFilter.createGrayscaleFilter())
    "Cerah" -> listOf(Contrast(0.15f), HslAdjustment.Builder().adjustSaturation(35f).build())
    "Hangat" -> listOf(RgbAdjustment.Builder().setRedScale(1.15f).setBlueScale(0.88f).build())
    "Dingin" -> listOf(RgbAdjustment.Builder().setRedScale(0.88f).setBlueScale(1.15f).build())
    "Drama" -> listOf(Contrast(0.35f), Brightness(-0.05f))
    "Pudar" -> listOf(Contrast(-0.25f), Brightness(0.08f), HslAdjustment.Builder().adjustSaturation(-30f).build())
    "Terang" -> listOf(Brightness(0.15f))
    else -> emptyList()
}

private fun mediaItemOf(c: Clip) = MediaItem.Builder().setUri(c.uri)
    .setClippingConfiguration(
        MediaItem.ClippingConfiguration.Builder().setStartPositionMs(c.startMs).setEndPositionMs(c.endMs).build()
    ).build()

class EditorViewModel(private val app: Application) : AndroidViewModel(app) {
    private val store = ProjectStore(app)
    private val ai = AiAssistant()
    val player: ExoPlayer = ExoPlayer.Builder(app).build()
    private val music: ExoPlayer = ExoPlayer.Builder(app).build()

    var project by mutableStateOf(Project("", "", "9:16"))
        private set
    var sel by mutableIntStateOf(0)
        private set
    var note by mutableStateOf<String?>(null)
    var busy by mutableStateOf(false)
    var stock by mutableStateOf<List<StockVideo>>(emptyList())
    val chat = mutableStateListOf(
        Msg(false, "Halo! Ketik perintah, mis. \"pisah di sini\", \"hitam putih\", \"percepat 2x\", " +
            "\"tambah teks Halo\", \"tambah kubus merah\", \"cari musik santai\", \"cari video pantai\".")
    )

    private val undoS = ArrayDeque<Project>()
    private val redoS = ArrayDeque<Project>()
    private var loaded = ""

    init {
        music.repeatMode = Player.REPEAT_MODE_ALL
        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = applyCurrent()
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (music.mediaItemCount > 0) { if (isPlaying) music.play() else music.pause() }
            }
        })
    }

    fun load(id: String) {
        if (loaded == id) return
        loaded = id
        project = store.load(id) ?: return
        rebuildPlayer(0)
        syncMusic()
    }

    // ---------- pemutar ----------
    private fun rebuildPlayer(keep: Int) {
        if (project.clips.isEmpty()) { player.clearMediaItems(); return }
        player.setMediaItems(project.clips.map { mediaItemOf(it) }, keep.coerceIn(0, project.clips.lastIndex), 0L)
        player.prepare()
        applyCurrent()
    }

    private fun applyCurrent() {
        val i = player.currentMediaItemIndex
        val c = project.clips.getOrNull(i) ?: return
        sel = i
        player.setPlaybackSpeed(c.speed)
        player.volume = c.volume
        player.setVideoEffects(effectsFor(c.filter))
    }

    private fun syncMusic() {
        music.stop(); music.clearMediaItems()
        project.music?.let { music.setMediaItem(MediaItem.fromUri(it.uri)); music.volume = it.volume; music.prepare() }
    }

    fun globalPos(): Long {
        val i = player.currentMediaItemIndex
        val c = project.clips.getOrNull(i) ?: return 0L
        return project.clips.take(i).sumOf { it.durationMs } + (player.currentPosition / c.speed).toLong()
    }

    fun seekGlobal(ms: Long) {
        var acc = 0L
        project.clips.forEachIndexed { i, c ->
            if (ms < acc + c.durationMs || i == project.clips.lastIndex) {
                player.seekTo(i, ((ms - acc).coerceAtLeast(0L) * c.speed).toLong()); return
            }
            acc += c.durationMs
        }
    }

    fun selectClip(i: Int) { sel = i; player.seekTo(i, 0L) }
    fun togglePlay() { if (player.isPlaying) player.pause() else player.play() }

    // ---------- riwayat ----------
    private fun commit(p: Project, rebuild: Boolean = false, keep: Int = sel) {
        undoS.addLast(project); if (undoS.size > 50) undoS.removeFirst()
        redoS.clear()
        setProject(p, rebuild, keep)
    }

    private fun setProject(p: Project, rebuild: Boolean, keep: Int) {
        val musicChanged = project.music != p.music
        project = p.copy(updated = System.currentTimeMillis())
        store.save(project)
        if (rebuild) rebuildPlayer(keep) else applyCurrent()
        if (musicChanged || rebuild) syncMusic()
    }

    fun undo() { val p = undoS.removeLastOrNull() ?: return; redoS.addLast(project); setProject(p, true, sel) }
    fun redo() { val p = redoS.removeLastOrNull() ?: return; undoS.addLast(project); setProject(p, true, sel) }

    // ---------- operasi klip ----------
    private fun durationOf(u: Uri): Long? = runCatching {
        MediaMetadataRetriever().run {
            try { setDataSource(app, u); extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() }
            finally { release() }
        }
    }.getOrNull()

    fun addClips(uris: List<Uri>) {
        if (uris.isEmpty()) return
        viewModelScope.launch {
            val add = withContext(Dispatchers.IO) {
                uris.mapNotNull { u ->
                    runCatching { app.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                    durationOf(u)?.let { Clip(u.toString(), 0L, it) }
                }
            }
            if (add.isEmpty()) { note = "Video tidak bisa dibaca."; return@launch }
            commit(project.copy(clips = project.clips + add), true, project.clips.size)
        }
    }

    fun split() {
        val i = player.currentMediaItemIndex
        val c = project.clips.getOrNull(i) ?: return
        val at = c.startMs + (player.currentPosition * c.speed).toLong()
        if (at < c.startMs + 300 || at > c.endMs - 300) { note = "Geser playhead ke tengah klip dulu."; return }
        val l = project.clips.toMutableList()
        l[i] = c.copy(endMs = at)
        l.add(i + 1, c.copy(startMs = at))
        commit(project.copy(clips = l), true, i + 1)
    }

    fun deleteSel() {
        if (project.clips.isEmpty()) return
        val l = project.clips.toMutableList(); l.removeAt(sel.coerceIn(0, l.lastIndex))
        commit(project.copy(clips = l), true, sel)
    }

    private fun updateSel(f: (Clip) -> Clip) {
        val i = sel.coerceIn(0, (project.clips.size - 1).coerceAtLeast(0))
        val l = project.clips.toMutableList(); if (l.isEmpty()) return
        l[i] = f(l[i]); commit(project.copy(clips = l))
    }

    fun setSpeed(v: Float) = updateSel { it.copy(speed = v.coerceIn(0.1f, 8f)) }
    fun setVolume(v: Float) = updateSel { it.copy(volume = v.coerceIn(0f, 1f)) }
    fun setFilter(name: String, all: Boolean = false) {
        if (all) commit(project.copy(clips = project.clips.map { it.copy(filter = name) }))
        else updateSel { it.copy(filter = name) }
    }

    // ---------- teks, 3D, musik ----------
    fun addText(t: String) { val g = globalPos(); commit(project.copy(texts = project.texts + TextItem(t, g, g + 3000))) }
    fun removeText(i: Int) { commit(project.copy(texts = project.texts.filterIndexed { k, _ -> k != i })) }
    fun addObj(shape: String, color: Long) { commit(project.copy(objs = project.objs + Obj3D(shape, color))) }
    fun removeObj(i: Int) { commit(project.copy(objs = project.objs.filterIndexed { k, _ -> k != i })) }

    fun setMusic(u: Uri) {
        runCatching { app.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        commit(project.copy(music = AudioItem(u.toString(), u.lastPathSegment ?: "musik")))
    }
    fun clearMusic() { commit(project.copy(music = null)) }
    fun setMusicVolume(v: Float) {
        val m = project.music ?: return
        music.volume = v; commit(project.copy(music = m.copy(volume = v)))
    }
    fun openMusicPage(q: String) {
        app.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(Pixabay.musicPageUrl(q))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    // ---------- stok Pixabay ----------
    fun searchStock(q: String) {
        viewModelScope.launch {
            busy = true
            try {
                stock = Pixabay.searchVideos(q)
                if (stock.isEmpty()) note = "Tidak ada hasil."
            } catch (e: Exception) { note = e.message ?: "Gagal mencari." } finally { busy = false }
        }
    }

    fun addStock(v: StockVideo) {
        viewModelScope.launch {
            busy = true
            try {
                val f = File(app.filesDir, "stock").apply { mkdirs() }.resolve("${v.id}.mp4")
                if (!f.exists()) Pixabay.download(v.url, f)
                val u = Uri.fromFile(f)
                val d = withContext(Dispatchers.IO) { durationOf(u) }
                if (d != null) commit(project.copy(clips = project.clips + Clip(u.toString(), 0L, d)), true, project.clips.size)
                else note = "Video stok tidak bisa dibaca."
            } catch (e: Exception) { note = "Gagal mengunduh: ${e.message}" } finally { busy = false }
        }
    }

    // ---------- asisten AI ----------
    val llama = LlamaEngine(app)
    var modelMsg by mutableStateOf<String?>(null)

    private val host = object : ToolHost {
        override fun snapshot() = snapshotJson()
        override fun call(tool: String, args: JSONObject) = callTool(tool, args)
    }

    private fun snapshotJson() = JSONObject().apply {
        put("rasio", project.ratio); put("total_detik", project.totalMs / 1000.0)
        put("playhead_detik", globalPos() / 1000.0); put("klip_terpilih", sel)
        put("klip", JSONArray().also { a ->
            project.clips.forEachIndexed { i, c ->
                a.put(JSONObject().put("i", i).put("sumber_detik", "${c.startMs / 1000.0}-${c.endMs / 1000.0}")
                    .put("durasi", c.durationMs / 1000.0).put("kecepatan", c.speed.toDouble())
                    .put("volume", c.volume.toDouble()).put("filter", c.filter))
            }
        })
        put("teks", JSONArray(project.texts.map { it.text }))
        put("objek3d", JSONArray(project.objs.map { it.shape }))
        put("musik", project.music?.name ?: JSONObject.NULL)
    }

    fun trimClip(i: Int, s: Long, e: Long) {
        val c = project.clips.getOrNull(i) ?: return
        val ns = s.coerceIn(c.startMs, c.endMs - 300); val ne = e.coerceIn(ns + 300, c.endMs)
        val l = project.clips.toMutableList(); l[i] = c.copy(startMs = ns, endMs = ne)
        commit(project.copy(clips = l), true, i)
    }

    fun addTextAt(t: String, s: Long, e: Long) { commit(project.copy(texts = project.texts + TextItem(t, s, e))) }

    /** Semua alat divalidasi di sini; galat dikembalikan ke model sebagai teks supaya ia bisa memperbaiki langkahnya. */
    private fun callTool(tool: String, a: JSONObject): String = runCatching {
        val n = project.clips.size
        fun idx(): Int { val i = if (a.has("index")) a.getInt("index") else sel; require(i in 0 until n) { "index $i di luar 0..${n - 1}" }; return i }
        fun ms(k: String) = (a.getDouble(k) * 1000).toLong()
        when (tool) {
            "select_clip" -> { selectClip(idx()); "ok" }
            "seek" -> { seekGlobal(ms("sec").coerceIn(0L, project.totalMs)); "ok" }
            "split" -> { split(); "ok" }
            "split_at" -> { seekGlobal(ms("sec").coerceIn(0L, project.totalMs)); split(); "ok" }
            "delete_clip" -> { selectClip(idx()); deleteSel(); "ok, sisa ${project.clips.size} klip" }
            "trim" -> { trimClip(idx(), ms("start"), ms("end")); "ok" }
            "set_speed" -> { selectClip(idx()); setSpeed(a.getDouble("value").toFloat()); "ok" }
            "set_volume" -> { selectClip(idx()); setVolume(a.getDouble("value").toFloat()); "ok" }
            "set_filter" -> {
                val f = a.getString("name"); require(f in com.potong.editor.data.FILTERS) { "filter tidak dikenal: $f" }
                if (!a.optBoolean("all") && a.has("index")) selectClip(idx())
                setFilter(f, a.optBoolean("all")); "ok"
            }
            "add_text" -> {
                val s = if (a.has("start")) ms("start") else globalPos()
                addTextAt(a.getString("text"), s, s + if (a.has("dur")) ms("dur") else 3000L); "ok"
            }
            "add_3d" -> {
                val sh = a.optString("shape", "kubus"); require(sh in com.potong.editor.data.SHAPES) { "bentuk tidak dikenal: $sh" }
                addObj(sh, com.potong.editor.data.COLORS[a.optString("color")] ?: 0xFF00BFA5L); "ok"
            }
            "find_music" -> { openMusicPage(a.optString("query")); "ok, halaman Pixabay Music dibuka di browser" }
            "find_stock" -> { searchStock(a.optString("query")); "ok, hasil di tab Stok" }
            "undo" -> { undo(); "ok" }
            else -> "alat tidak dikenal: $tool"
        }
    }.getOrElse { "galat: ${it.message}" }

    fun importModel(u: Uri) {
        viewModelScope.launch {
            busy = true; modelMsg = "Menyalin model..."
            modelMsg = if (llama.importModel(u)) (llama.load() ?: "Qwen siap (offline).") else "Gagal menyalin model."
            busy = false
        }
    }

    fun ask(text: String) {
        chat.add(Msg(true, text))
        viewModelScope.launch {
            if (!llama.ready && llama.hasModel && LlamaEngine.nativeOk) { modelMsg = "Memuat model..."; busy = true; modelMsg = llama.load() ?: "Qwen siap (offline)."; busy = false }
            if (llama.ready) {
                busy = true
                try { Agent(llama, host).run(text) { say(it) } } catch (e: Exception) { say("Agen gagal: ${e.message}") } finally { busy = false }
            } else ai.handle(text).forEach { run(it) }   // cadangan: pembaca kata kunci
        }
    }

    private fun say(t: String) { chat.add(Msg(false, t)) }

    private fun run(c: Cmd) {
        when (c) {
            Cmd.Split -> { split(); say("Klip dipisah di posisi playhead.") }
            Cmd.DeleteClip -> { deleteSel(); say("Klip terpilih dihapus.") }
            Cmd.Undo -> { undo(); say("Dibatalkan.") }
            Cmd.Redo -> { redo(); say("Diulang.") }
            is Cmd.Speed -> { setSpeed(c.v); say("Kecepatan klip ${c.v}x (hanya preview, belum ikut ekspor).") }
            is Cmd.Volume -> { setVolume(c.v); say("Volume klip diatur.") }
            is Cmd.Filter -> { setFilter(c.name, c.all); say("Filter ${c.name} dipasang${if (c.all) " ke semua klip" else ""}.") }
            is Cmd.AddText -> { addText(c.text); say("Teks \"${c.text}\" ditambahkan di playhead.") }
            is Cmd.Add3D -> { addObj(c.shape, c.color); say("Objek 3D ${c.shape} ditambahkan.") }
            is Cmd.FindMusic -> {
                openMusicPage(c.query)
                say("Saya buka Pixabay Music. Unduh lagunya, lalu di tab Audio tekan Impor musik.")
            }
            is Cmd.FindStock -> { searchStock(c.query); say("Mencari video stok. Hasil ada di tab Stok.") }
            is Cmd.Say -> say(c.text)
        }
    }

    // ---------- ekspor ----------
    fun export() {
        if (project.clips.isEmpty() || busy) return
        busy = true; note = "Mengekspor..."
        val out = File(app.cacheDir, "out_${System.currentTimeMillis()}.mp4")
        val crop = Presentation.createForAspectRatio(project.aspect, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP)
        val items = project.clips.map { c ->
            EditedMediaItem.Builder(mediaItemOf(c)).setEffects(Effects(emptyList(), effectsFor(c.filter) + crop)).build()
        }
        val comp = Composition.Builder(listOf(EditedMediaItemSequence(items))).build()
        val t = Transformer.Builder(app).setVideoMimeType(MimeTypes.VIDEO_H264)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) { saveToGallery(out) }
                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    busy = false; note = "Ekspor gagal: ${exportException.message}"
                }
            }).build()
        t.start(comp, out.absolutePath)
    }

    private fun saveToGallery(f: File) {
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                val v = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, "Potong_${System.currentTimeMillis()}.mp4")
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Potong")
                }
                val uri = app.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
                if (uri == null) false else {
                    app.contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
                    f.delete(); true
                }
            }
            busy = false
            note = if (ok) "Tersimpan di Movies/Potong (gabungan klip, trim, filter, rasio)." else "Gagal menyimpan ke galeri."
        }
    }

    override fun onCleared() { llama.unload(); player.release(); music.release() }
}
