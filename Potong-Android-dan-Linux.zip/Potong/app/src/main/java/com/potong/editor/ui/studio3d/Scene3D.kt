package com.potong.editor.ui.studio3d

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import com.potong.editor.data.Obj3D
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

class Mesh(val v: Array<FloatArray>, val f: Array<IntArray>)

private fun f3(x: Float, y: Float, z: Float) = floatArrayOf(x, y, z)

private val cube = Mesh(
    arrayOf(f3(-1f, -1f, -1f), f3(1f, -1f, -1f), f3(1f, 1f, -1f), f3(-1f, 1f, -1f),
        f3(-1f, -1f, 1f), f3(1f, -1f, 1f), f3(1f, 1f, 1f), f3(-1f, 1f, 1f)),
    arrayOf(intArrayOf(0, 1, 2, 3), intArrayOf(4, 5, 6, 7), intArrayOf(0, 1, 5, 4),
        intArrayOf(2, 3, 7, 6), intArrayOf(1, 2, 6, 5), intArrayOf(0, 3, 7, 4))
)
private val pyramid = Mesh(
    arrayOf(f3(-1f, -1f, -1f), f3(1f, -1f, -1f), f3(1f, -1f, 1f), f3(-1f, -1f, 1f), f3(0f, 1.2f, 0f)),
    arrayOf(intArrayOf(0, 1, 2, 3), intArrayOf(0, 1, 4), intArrayOf(1, 2, 4), intArrayOf(2, 3, 4), intArrayOf(3, 0, 4))
)
private val prism = Mesh(
    arrayOf(f3(-1f, -1f, -1f), f3(1f, -1f, -1f), f3(0f, 1f, -1f), f3(-1f, -1f, 1f), f3(1f, -1f, 1f), f3(0f, 1f, 1f)),
    arrayOf(intArrayOf(0, 1, 2), intArrayOf(3, 4, 5), intArrayOf(0, 1, 4, 3), intArrayOf(1, 2, 5, 4), intArrayOf(2, 0, 3, 5))
)
private val sphere: Mesh = run {
    val lat = 8
    val lon = 12
    val v = ArrayList<FloatArray>()
    for (i in 0..lat) {
        val a = PI.toFloat() * i / lat
        for (j in 0 until lon) {
            val b = 2f * PI.toFloat() * j / lon
            v.add(f3(sin(a) * cos(b), cos(a), sin(a) * sin(b)))
        }
    }
    val f = ArrayList<IntArray>()
    for (i in 0 until lat) for (j in 0 until lon) {
        val j2 = (j + 1) % lon
        f.add(intArrayOf(i * lon + j, i * lon + j2, (i + 1) * lon + j2, (i + 1) * lon + j))
    }
    Mesh(v.toTypedArray(), f.toTypedArray())
}

private fun meshOf(shape: String) = when (shape) {
    "piramida" -> pyramid
    "prisma" -> prism
    "bola" -> sphere
    else -> cube
}

private fun DrawScope.drawMesh(m: Mesh, cx: Float, cy: Float, s: Float, deg: Float, base: Color) {
    val ay = (deg * PI / 180.0).toFloat()
    val ax = 0.45f
    val ca = cos(ay); val sa = sin(ay); val cb = cos(ax); val sb = sin(ax)
    val t = Array(m.v.size) { i ->
        val x = m.v[i][0]; val y = m.v[i][1]; val z = m.v[i][2]
        val x1 = x * ca + z * sa
        val z1 = -x * sa + z * ca
        floatArrayOf(x1, y * cb - z1 * sb, y * sb + z1 * cb)
    }
    val order = m.f.sortedByDescending { idx -> idx.map { t[it][2] }.average() }
    for (idx in order) {
        val a = t[idx[0]]; val b = t[idx[1]]; val c = t[idx[2]]
        val ux = b[0] - a[0]; val uy = b[1] - a[1]; val uz = b[2] - a[2]
        val vx = c[0] - a[0]; val vy = c[1] - a[1]; val vz = c[2] - a[2]
        val nx = uy * vz - uz * vy; val ny = uz * vx - ux * vz; val nz = ux * vy - uy * vx
        val len = sqrt(nx * nx + ny * ny + nz * nz)
        if (len < 1e-6f) continue
        val light = 0.35f + 0.65f * abs((nx * -0.4f + ny * 0.6f + nz * -0.7f) / (len * 1.0344f))
        val path = Path()
        idx.forEachIndexed { k, vi ->
            val q = t[vi]
            val pr = 5f / (5f + q[2])
            val px = cx + q[0] * s * pr
            val py = cy - q[1] * s * pr
            if (k == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        path.close()
        drawPath(path, Color(base.red * light, base.green * light, base.blue * light, 1f))
        drawPath(path, Color.Black.copy(alpha = 0.25f), style = Stroke(1.5f))
    }
}

/** Objek 3D berputar, digambar dengan proyeksi perspektif sederhana (tanpa OpenGL). */
@Composable
fun Scene3DView(objs: List<Obj3D>, modifier: Modifier = Modifier) {
    val tr = rememberInfiniteTransition(label = "spin")
    val ang by tr.animateFloat(
        0f, 360f, infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Restart), label = "ang"
    )
    Canvas(modifier) {
        val n = objs.size.coerceAtLeast(1)
        val w = size.width / n
        objs.forEachIndexed { i, o ->
            drawMesh(meshOf(o.shape), w * (i + 0.5f), size.height / 2f, minOf(w, size.height) * 0.3f, ang + i * 40f, Color(o.color))
        }
    }
}
