package com.potong.editor.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Clip(
    val uri: String, val startMs: Long, val endMs: Long,
    val speed: Float = 1f, val volume: Float = 1f, val filter: String = "Normal"
) {
    val durationMs: Long get() = ((endMs - startMs) / speed).toLong()
}
data class TextItem(val text: String, val startMs: Long, val endMs: Long)
data class Obj3D(val shape: String, val color: Long)
data class AudioItem(val uri: String, val name: String, val volume: Float = 0.8f)
data class Project(
    val id: String, val name: String, val ratio: String,
    val clips: List<Clip> = emptyList(), val texts: List<TextItem> = emptyList(),
    val objs: List<Obj3D> = emptyList(), val music: AudioItem? = null,
    val updated: Long = System.currentTimeMillis()
) {
    val totalMs: Long get() = clips.sumOf { it.durationMs }
    val aspect: Float get() { val p = ratio.split(":"); return p[0].toFloat() / p[1].toFloat() }
}

val FILTERS = listOf("Normal", "Hitam putih", "Cerah", "Hangat", "Dingin", "Drama", "Pudar", "Terang")
val SHAPES = listOf("kubus", "piramida", "prisma", "bola")
val COLORS = linkedMapOf(
    "merah" to 0xFFE53935L, "biru" to 0xFF1E88E5L, "hijau" to 0xFF43A047L, "kuning" to 0xFFFDD835L,
    "ungu" to 0xFF8E24AAL, "oranye" to 0xFFFB8C00L, "putih" to 0xFFFFFFFFL, "toska" to 0xFF00BFA5L
)

private fun <T> List<T>.arr(f: (T) -> JSONObject) = JSONArray().also { a -> forEach { a.put(f(it)) } }
private fun <T> JSONArray?.objs(f: (JSONObject) -> T): List<T> =
    if (this == null) emptyList() else (0 until length()).map { f(getJSONObject(it)) }

private fun Project.toJson() = JSONObject().apply {
    put("id", id); put("name", name); put("ratio", ratio); put("updated", updated)
    put("clips", clips.arr { JSONObject().put("u", it.uri).put("s", it.startMs).put("e", it.endMs)
        .put("sp", it.speed.toDouble()).put("v", it.volume.toDouble()).put("f", it.filter) })
    put("texts", texts.arr { JSONObject().put("t", it.text).put("s", it.startMs).put("e", it.endMs) })
    put("objs", objs.arr { JSONObject().put("s", it.shape).put("c", it.color) })
    music?.let { put("music", JSONObject().put("u", it.uri).put("n", it.name).put("v", it.volume.toDouble())) }
}

private fun projectOf(o: JSONObject) = Project(
    id = o.getString("id"), name = o.getString("name"), ratio = o.getString("ratio"),
    clips = o.optJSONArray("clips").objs {
        Clip(it.getString("u"), it.getLong("s"), it.getLong("e"), it.optDouble("sp", 1.0).toFloat(),
            it.optDouble("v", 1.0).toFloat(), it.optString("f", "Normal"))
    },
    texts = o.optJSONArray("texts").objs { TextItem(it.getString("t"), it.getLong("s"), it.getLong("e")) },
    objs = o.optJSONArray("objs").objs { Obj3D(it.getString("s"), it.getLong("c")) },
    music = o.optJSONObject("music")?.let { AudioItem(it.getString("u"), it.getString("n"), it.optDouble("v", 0.8).toFloat()) },
    updated = o.optLong("updated")
)

/** Draf proyek disimpan sebagai JSON di penyimpanan internal aplikasi. */
class ProjectStore(ctx: Context) {
    private val dir = File(ctx.filesDir, "projects").apply { mkdirs() }
    fun list(): List<Project> = dir.listFiles()
        ?.mapNotNull { f -> runCatching { projectOf(JSONObject(f.readText())) }.getOrNull() }
        ?.sortedByDescending { it.updated } ?: emptyList()
    fun load(id: String): Project? = runCatching { projectOf(JSONObject(File(dir, "$id.json").readText())) }.getOrNull()
    fun save(p: Project) { File(dir, "${p.id}.json").writeText(p.toJson().toString()) }
    fun delete(id: String) { File(dir, "$id.json").delete() }
}
