# Potong Desktop (Linux) - Compose Desktop + FFmpeg + VLC + Qwen (llama-server)
Butuh (Ubuntu/Debian): `sudo apt install openjdk-17-jdk ffmpeg vlc gradle` (Gradle 8.5+; kalau versi apt lama, pasang lewat SDKMAN).
Jalankan: `cd desktop && gradle run`
Qwen offline: unduh llama-server dari rilis llama.cpp (ubuntu-x64) atau build sendiri, unduh model Qwen2.5 Instruct GGUF (1.5B Q4_K_M),
lalu tab AI: isi path llama-server (atau biarkan `llama-server` bila ada di PATH), pilih model, tekan Mulai Qwen.
Hasil ekspor: ~/Videos/Potong-*.mp4. Preview memutar klip terpilih apa adanya (tanpa filter); filter, teks, kecepatan, dan musik terlihat di hasil ekspor.
Paket .deb: `gradle packageDeb`.
