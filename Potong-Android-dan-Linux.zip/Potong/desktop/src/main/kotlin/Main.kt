import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.awt.SwingPanel
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import uk.co.caprica.vlcj.player.component.EmbeddedMediaPlayerComponent
import java.awt.FileDialog
import java.awt.Frame
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

// ---------------- data ----------------
data class Clip(val path: String, val start: Double, val end: Double, val speed: Double = 1.0, val volume: Double = 1.0, val filter: String = "Normal")
data class Txt(val text: String, val start: Double, val dur: Double)
data class Proj(val clips: List<Clip> = emptyList(), val texts: List<Txt> = emptyList(), val music: String? = null, val w: Int = 1080, val h: Int = 1920)

val VF = mapOf(
    "Hitam putih" to "hue=s=0", "Cerah" to "eq=contrast=1.15:saturation=1.4", "Gelap" to "eq=brightness=-0.12",
    "Hangat" to "colorbalance=rs=0.1:bs=-0.1", "Dingin" to "colorbalance=rs=-0.1:bs=0.1",
    "Drama" to "eq=contrast=1.3:saturation=0.8:brightness=-0.05", "Pudar" to "eq=contrast=0.85:brightness=0.08:saturation=0.7",
    "Terang" to "eq=brightness=0.1"
)
val FILTER_NAMES = listOf("Normal") + VF.keys

fun sh(vararg cmd: String): String = ProcessBuilder(*cmd).redirectErrorStream(true).start().let { p ->
    val o = p.inputStream.bufferedReader().readText(); p.waitFor(); o
}
fun tempo(s: Double) = when { s > 2 -> "atempo=2.0,atempo=${s / 2},"; s < 0.5 -> "atempo=0.5,atempo=${s / 0.5},"; s == 1.0 -> ""; else -> "atempo=$s," }

// ---------------- Qwen lewat llama-server (llama.cpp) ----------------
const val AGENT_SYSTEM = """Kamu agen editor video. Lihat KONDISI PROYEK (JSON), lalu balas HANYA satu objek JSON:
{"say":"penjelasan singkat","calls":[{"tool":"nama","args":{}}],"done":false}
Setelah alat dijalankan kamu melihat hasilnya dan boleh lanjut. Isi "done":true bila tugas selesai. Indeks klip mulai dari 0, waktu dalam detik.
Alat: select_clip{index} | split_at{sec} | delete_clip{index} | trim{index,start,end} (detik sumber klip) | set_speed{index,value 0.25-4} | set_volume{index,value 0-1} | set_filter{name,index} | add_text{text,start,dur} | undo{}
Filter: Normal, Hitam putih, Cerah, Gelap, Hangat, Dingin, Drama, Pudar, Terang.
Contoh: permintaan "pisah di detik 5 lalu hitam putih" -> {"say":"Memisah lalu memberi filter","calls":[{"tool":"split_at","args":{"sec":5}},{"tool":"set_filter","args":{"name":"Hitam putih","index":1}}],"done":true}
Jika permintaan tidak bisa dilakukan, jelaskan di "say" dengan "calls":[] dan "done":true."""

class Llm {
    private var proc: Process? = null
    private val port = 8089
    var ready by mutableStateOf(false); private set

    private fun health() = runCatching { (URL("http://127.0.0.1:$port/health").openConnection() as HttpURLConnection).responseCode == 200 }.getOrDefault(false)

    suspend fun start(bin: String, model: String): String? = withContext(Dispatchers.IO) {
        stop()
        if (!File(model).exists()) return@withContext "File model tidak ditemukan."
        val p = runCatching {
            ProcessBuilder(bin, "-m", model, "-c", "4096", "--host", "127.0.0.1", "--port", "$port")
                .redirectErrorStream(true).redirectOutput(ProcessBuilder.Redirect.DISCARD).start()
        }.getOrElse { return@withContext "llama-server tidak bisa dijalankan: ${it.message}" }
        proc = p
        repeat(180) {
            delay(1000)
            if (health()) { ready = true; return@withContext null }
            if (!p.isAlive) return@withContext "llama-server berhenti (model/RAM bermasalah)."
        }
        "Waktu habis saat memuat model."
    }

    fun stop() { ready = false; proc?.destroy(); proc = null }

    suspend fun generate(prompt: String): String = withContext(Dispatchers.IO) {
        val c = URL("http://127.0.0.1:$port/completion").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.readTimeout = 300_000
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(JSONObject().put("prompt", prompt).put("n_predict", 384).put("temperature", 0.2)
            .put("stop", JSONArray().put("<|im_end|>")).toString().toByteArray()) }
        JSONObject(c.inputStream.bufferedReader().readText()).optString("content")
    }
}

// ---------------- editor ----------------
class Editor(private val scope: CoroutineScope) {
    var p by mutableStateOf(Proj()); private set
    var sel by mutableStateOf(-1)
    var busy by mutableStateOf(false)
    var note by mutableStateOf("")
    var playhead by mutableStateOf(0.0)
    var llmMsg by mutableStateOf("Qwen belum dimulai")
    val chat = mutableStateListOf<Pair<Boolean, String>>()
    val llm = Llm()
    private val undoS = ArrayDeque<Proj>()

    val total get() = p.clips.sumOf { (it.end - it.start) / it.speed }
    private fun commit(n: Proj) { undoS.addLast(p); if (undoS.size > 100) undoS.removeFirst(); p = n }
    fun undo() { undoS.removeLastOrNull()?.let { p = it } }
    private fun upd(i: Int, f: (Clip) -> Clip) { if (i in p.clips.indices) commit(p.copy(clips = p.clips.mapIndexed { k, c -> if (k == i) f(c) else c })) }

    fun add(files: List<File>) {
        scope.launch(Dispatchers.IO) {
            busy = true
            val added = files.mapNotNull { f ->
                val d = runCatching { sh("ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", f.absolutePath).trim().toDouble() }.getOrNull()
                d?.let { Clip(f.absolutePath, 0.0, it) }
            }
            if (added.isEmpty()) note = "Gagal membaca video. Pastikan ffmpeg terpasang."
            else { commit(p.copy(clips = p.clips + added)); sel = p.clips.lastIndex; note = "" }
            busy = false
        }
    }
    fun split(g: Double) {
        var acc = 0.0
        for (c in p.clips) {
            val len = (c.end - c.start) / c.speed
            if (g > acc && g < acc + len) {
                val src = c.start + (g - acc) * c.speed
                if (src - c.start > 0.3 && c.end - src > 0.3)
                    commit(p.copy(clips = p.clips.flatMap { if (it === c) listOf(c.copy(end = src), c.copy(start = src)) else listOf(it) }))
                return
            }
            acc += len
        }
    }
    fun delete(i: Int) { if (i in p.clips.indices) { commit(p.copy(clips = p.clips.filterIndexed { k, _ -> k != i })); sel = p.clips.lastIndex } }
    fun speed(i: Int, v: Double) = upd(i) { it.copy(speed = v.coerceIn(0.25, 4.0)) }
    fun volume(i: Int, v: Double) = upd(i) { it.copy(volume = v.coerceIn(0.0, 1.0)) }
    fun filter(i: Int, n: String) = upd(i) { it.copy(filter = n) }
    fun trim(i: Int, s: Double, e: Double) = upd(i) { val ns = s.coerceIn(it.start, it.end - 0.3); it.copy(start = ns, end = e.coerceIn(ns + 0.3, it.end)) }
    fun text(t: String, s: Double, d: Double) = commit(p.copy(texts = p.texts + Txt(t, s, d)))
    fun removeText(i: Int) = commit(p.copy(texts = p.texts.filterIndexed { k, _ -> k != i }))
    fun music(path: String?) = commit(p.copy(music = path))

    // ---- ekspor lewat ffmpeg ----
    private fun hasAudio(f: String) = runCatching { sh("ffprobe", "-v", "error", "-select_streams", "a", "-show_entries", "stream=index", "-of", "csv=p=0", f).isNotBlank() }.getOrDefault(true)

    fun export() {
        scope.launch(Dispatchers.IO) {
            busy = true; note = "Mengekspor..."
            val out = File(System.getProperty("user.home"), "Videos").apply { mkdirs() }.resolve("Potong-${System.currentTimeMillis() / 1000}.mp4").absolutePath
            val c = p.clips
            val cmd = mutableListOf("ffmpeg", "-y")
            c.forEach { cmd += listOf("-i", it.path) }
            p.music?.let { cmd += listOf("-i", it) }
            val g = StringBuilder()
            c.forEachIndexed { i, k ->
                val d = (k.end - k.start) / k.speed
                g.append("[$i:v]trim=start=${k.start}:end=${k.end},setpts=(PTS-STARTPTS)/${k.speed},scale=${p.w}:${p.h}:force_original_aspect_ratio=decrease,pad=${p.w}:${p.h}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30${VF[k.filter]?.let { "," + it } ?: ""}[v$i];")
                if (hasAudio(k.path)) g.append("[$i:a]atrim=start=${k.start}:end=${k.end},asetpts=PTS-STARTPTS,${tempo(k.speed)}volume=${k.volume},aresample=44100,aformat=channel_layouts=stereo[a$i];")
                else g.append("anullsrc=r=44100:cl=stereo,atrim=duration=$d,asetpts=PTS-STARTPTS[a$i];")
            }
            g.append(c.indices.joinToString("") { "[v$it][a$it]" } + "concat=n=${c.size}:v=1:a=1[vc][ac]")
            var vl = "vc"
            p.texts.forEachIndexed { i, t ->
                val f = File.createTempFile("potong_t$i", ".txt").apply { writeText(t.text); deleteOnExit() }
                g.append(";[$vl]drawtext=textfile='${f.absolutePath}':expansion=none:fontcolor=white:fontsize=h/18:x=(w-text_w)/2:y=h*0.8:box=1:boxcolor=black@0.5:boxborderw=12:enable='between(t,${t.start},${t.start + t.dur})'[vt$i]")
                vl = "vt$i"
            }
            var al = "ac"
            if (p.music != null) { g.append(";[${c.size}:a]volume=0.5[m];[ac][m]amix=inputs=2:duration=first:dropout_transition=0[am]"); al = "am" }
            cmd += listOf("-filter_complex", g.toString(), "-map", "[$vl]", "-map", "[$al]", "-c:v", "libx264", "-preset", "veryfast", "-crf", "20",
                "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart", out)
            note = runCatching {
                val pr = ProcessBuilder(cmd).redirectErrorStream(true).start()
                val tail = ArrayDeque<String>()
                pr.inputStream.bufferedReader().forEachLine { tail.addLast(it); if (tail.size > 4) tail.removeFirst() }
                if (pr.waitFor() == 0) "Selesai: $out" else "Ekspor gagal: ${tail.joinToString(" | ")}"
            }.getOrElse { "ffmpeg tidak ditemukan (sudo apt install ffmpeg)." }
            busy = false
        }
    }

    // ---- agen ----
    private fun snapshot() = JSONObject().apply {
        put("total_detik", total); put("playhead_detik", playhead); put("klip_terpilih", sel)
        put("klip", JSONArray().also { a -> p.clips.forEachIndexed { i, c ->
            a.put(JSONObject().put("i", i).put("sumber_detik", "${c.start}-${c.end}").put("kecepatan", c.speed).put("volume", c.volume).put("filter", c.filter)) } })
        put("teks", JSONArray(p.texts.map { it.text }))
    }

    private fun tool(name: String, a: JSONObject): String = runCatching {
        val n = p.clips.size
        fun idx(): Int { val i = if (a.has("index")) a.getInt("index") else sel; require(i in 0 until n) { "index $i di luar 0..${n - 1}" }; return i }
        when (name) {
            "select_clip" -> { sel = idx(); "ok" }
            "split_at" -> { split(a.getDouble("sec")); "ok, sekarang ${p.clips.size} klip" }
            "delete_clip" -> { delete(idx()); "ok" }
            "trim" -> { trim(idx(), a.getDouble("start"), a.getDouble("end")); "ok" }
            "set_speed" -> { speed(idx(), a.getDouble("value")); "ok" }
            "set_volume" -> { volume(idx(), a.getDouble("value")); "ok" }
            "set_filter" -> { val f = a.getString("name"); require(f in FILTER_NAMES) { "filter tidak dikenal: $f" }; filter(idx(), f); "ok" }
            "add_text" -> { text(a.getString("text"), a.optDouble("start", playhead), a.optDouble("dur", 3.0)); "ok" }
            "undo" -> { undo(); "ok" }
            else -> "alat tidak dikenal: $name"
        }
    }.getOrElse { "galat: ${it.message}" }

    private fun say(t: String) { chat += false to t }

    fun startQwen(bin: String, model: String) {
        scope.launch { busy = true; llmMsg = "Memuat model (bisa lama)..."; llmMsg = llm.start(bin, model) ?: "Qwen aktif (offline)"; busy = false }
    }

    fun ask(text: String) {
        chat += true to text
        scope.launch {
            if (!llm.ready) { say("Qwen belum aktif. Isi path llama-server dan model, lalu tekan Mulai Qwen."); return@launch }
            busy = true
            try {
                val obs = StringBuilder()
                repeat(6) {
                    val prompt = "<|im_start|>system\n$AGENT_SYSTEM<|im_end|>\n<|im_start|>user\nKONDISI PROYEK:\n${snapshot()}\n\nPERMINTAAN: $text\n" +
                        (if (obs.isNotEmpty()) "\nHASIL ALAT SEBELUMNYA:\n$obs" else "") + "<|im_end|>\n<|im_start|>assistant\n"
                    val raw = llm.generate(prompt)
                    val j = runCatching { JSONObject(raw.substring(raw.indexOf('{'), raw.lastIndexOf('}') + 1)) }.getOrNull()
                    if (j == null) { obs.append("- Balasan bukan JSON valid. Balas hanya JSON.\n"); return@repeat }
                    j.optString("say").takeIf { it.isNotBlank() }?.let { say(it) }
                    val calls = j.optJSONArray("calls"); val m = calls?.length() ?: 0
                    for (k in 0 until m) {
                        val c = calls!!.optJSONObject(k) ?: continue
                        val r = tool(c.optString("tool"), c.optJSONObject("args") ?: JSONObject())
                        say("• ${c.optString("tool")} → $r"); obs.append("- ${c.optString("tool")} -> $r\n")
                    }
                    if (m == 0 || j.optBoolean("done")) { busy = false; return@launch }
                }
                say("Batas 6 langkah tercapai.")
            } catch (e: Exception) { say("Agen gagal: ${e.message}") } finally { busy = false }
        }
    }
}

// ---------------- UI ----------------
fun pick(title: String, multi: Boolean = true): List<File> {
    val d = FileDialog(null as Frame?, title, FileDialog.LOAD).apply { isMultipleMode = multi; isVisible = true }
    return d.files.toList()
}
private fun fmt(s: Double) = "%d:%02d".format(s.toInt() / 60, s.toInt() % 60)

@OptIn(ExperimentalComposeUiApi::class)
fun main() = application {
    Window(onCloseRequest = ::exitApplication, title = "Potong", state = rememberWindowState(width = 1280.dp, height = 800.dp)) {
        MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF00E5FF), onPrimary = Color.Black)) { Surface(Modifier.fillMaxSize()) { App() } }
    }
}

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun App() {
    val scope = rememberCoroutineScope()
    val ed = remember { Editor(scope) }
    var tab by remember { mutableStateOf(0) }
    val vlc = remember { runCatching { EmbeddedMediaPlayerComponent() }.getOrNull() }
    DisposableEffect(Unit) { onDispose { vlc?.release(); ed.llm.stop() } }
    LaunchedEffect(ed.sel, ed.p.clips) {
        ed.p.clips.getOrNull(ed.sel)?.let { c ->
            vlc?.mediaPlayer()?.media()?.play(c.path, ":start-time=${c.start}", ":stop-time=${c.end}")
            vlc?.mediaPlayer()?.controls()?.setRate(c.speed.toFloat())
        }
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Potong", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Button(onClick = { ed.add(pick("Pilih video")) }, enabled = !ed.busy) { Text("+ Video") }
            OutlinedButton(onClick = { ed.undo() }) { Text("Urung") }
            Spacer(Modifier.weight(1f))
            Text(ed.note, fontSize = 12.sp, color = Color.Gray, maxLines = 1, modifier = Modifier.widthIn(max = 520.dp))
            Button(onClick = { ed.export() }, enabled = !ed.busy && ed.p.clips.isNotEmpty()) { Text("Ekspor MP4") }
        }
        if (ed.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        Row(Modifier.weight(1f)) {
            Box(Modifier.weight(1f).fillMaxHeight().background(Color.Black), contentAlignment = Alignment.Center) {
                if (vlc != null) SwingPanel(factory = { vlc }, modifier = Modifier.fillMaxSize())
                else Text("Pasang VLC (sudo apt install vlc) untuk preview.", color = Color.Gray)
            }
            Column(Modifier.width(380.dp).fillMaxHeight().padding(8.dp)) {
                TabRow(selectedTabIndex = tab) { listOf("Klip", "Teks", "Audio", "AI").forEachIndexed { i, t -> Tab(tab == i, { tab = i }, text = { Text(t) }) } }
                Spacer(Modifier.height(8.dp))
                when (tab) { 0 -> ClipPanel(ed); 1 -> TextPanel(ed); 2 -> AudioPanel(ed); else -> AiPanel(ed) }
            }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("${fmt(ed.playhead)} / ${fmt(ed.total)}", fontSize = 12.sp, modifier = Modifier.width(90.dp))
            Slider(ed.playhead.toFloat().coerceIn(0f, maxOf(ed.total, 1.0).toFloat()), { ed.playhead = it.toDouble() },
                valueRange = 0f..maxOf(ed.total, 1.0).toFloat(), modifier = Modifier.weight(1f))
            OutlinedButton(onClick = { ed.split(ed.playhead) }) { Text("Pisah di sini") }
        }
        LazyRow(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            itemsIndexed(ed.p.clips) { i, c ->
                Box(Modifier.width(((c.end - c.start) / c.speed * 18).dp.coerceAtLeast(70.dp)).height(46.dp)
                    .background(if (i == ed.sel) MaterialTheme.colorScheme.primary else Color(0xFF2E3B4E), RoundedCornerShape(6.dp))
                    .clickable { ed.sel = i }.padding(6.dp)) {
                    Text("${i + 1} · ${fmt((c.end - c.start) / c.speed)}${if (c.speed != 1.0) " · ${c.speed}x" else ""}", fontSize = 11.sp,
                        color = if (i == ed.sel) Color.Black else Color.White)
                }
            }
        }
    }
}

@Composable
fun ClipPanel(ed: Editor) {
    val c = ed.p.clips.getOrNull(ed.sel)
    if (c == null) { Text("Tambahkan video, lalu pilih klip di timeline.", color = Color.Gray); return }
    var sp by remember(ed.sel, c.speed) { mutableStateOf(c.speed.toFloat()) }
    var vo by remember(ed.sel, c.volume) { mutableStateOf(c.volume.toFloat()) }
    Text(File(c.path).name, maxLines = 1, fontSize = 12.sp)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = { ed.delete(ed.sel) }) { Text("Hapus klip") }
    }
    Text("Kecepatan ${"%.2f".format(sp)}x", fontSize = 12.sp, color = Color.Gray)
    Slider(sp, { sp = it }, valueRange = 0.25f..4f, onValueChangeFinished = { ed.speed(ed.sel, sp.toDouble()) })
    Text("Volume ${(vo * 100).toInt()}%", fontSize = 12.sp, color = Color.Gray)
    Slider(vo, { vo = it }, valueRange = 0f..1f, onValueChangeFinished = { ed.volume(ed.sel, vo.toDouble()) })
    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        itemsIndexed(FILTER_NAMES) { _, f -> FilterChip(selected = c.filter == f, onClick = { ed.filter(ed.sel, f) }, label = { Text(f) }) }
    }
    Text("Filter terlihat di hasil ekspor, belum di preview.", fontSize = 11.sp, color = Color.Gray)
}

@Composable
fun TextPanel(ed: Editor) {
    var t by remember { mutableStateOf("") }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(t, { t = it }, Modifier.weight(1f), placeholder = { Text("Isi teks") }, singleLine = true)
        Button(onClick = { if (t.isNotBlank()) { ed.text(t.trim(), ed.playhead, 3.0); t = "" } }) { Text("Tambah") }
    }
    Text("Teks tampil 3 detik dari posisi slider. Muncul di hasil ekspor.", fontSize = 11.sp, color = Color.Gray)
    LazyColumn { itemsIndexed(ed.p.texts) { i, x ->
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("${fmt(x.start)}  ${x.text}", Modifier.weight(1f))
            TextButton(onClick = { ed.removeText(i) }) { Text("Hapus") }
        }
    } }
}

@Composable
fun AudioPanel(ed: Editor) {
    Button(onClick = { pick("Pilih musik", false).firstOrNull()?.let { ed.music(it.absolutePath) } }) { Text("Pilih musik") }
    Text(ed.p.music?.let { File(it).name } ?: "Belum ada musik.", fontSize = 12.sp, color = Color.Gray)
    if (ed.p.music != null) TextButton(onClick = { ed.music(null) }) { Text("Hapus musik") }
    Text("Cari musik bebas hak cipta di pixabay.com/music, unduh, lalu pilih di sini.", fontSize = 11.sp, color = Color.Gray)
}

@Composable
fun AiPanel(ed: Editor) {
    var bin by remember { mutableStateOf("llama-server") }
    var model by remember { mutableStateOf("") }
    var t by remember { mutableStateOf("") }
    val ls = rememberLazyListState()
    LaunchedEffect(ed.chat.size) { if (ed.chat.isNotEmpty()) ls.animateScrollToItem(ed.chat.lastIndex) }
    OutlinedTextField(bin, { bin = it }, Modifier.fillMaxWidth(), label = { Text("Path llama-server") }, singleLine = true)
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        OutlinedTextField(model, { model = it }, Modifier.weight(1f), label = { Text("Model .gguf (Qwen)") }, singleLine = true)
        OutlinedButton(onClick = { pick("Pilih model GGUF", false).firstOrNull()?.let { model = it.absolutePath } }) { Text("...") }
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { ed.startQwen(bin, model) }, enabled = !ed.busy) { Text("Mulai Qwen") }
        Text(ed.llmMsg, fontSize = 11.sp, color = Color.Gray)
    }
    LazyColumn(Modifier.weight(1f).padding(vertical = 6.dp), ls, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        itemsIndexed(ed.chat) { _, m ->
            Text(m.second, fontSize = 13.sp, color = if (m.first) Color.Black else Color.White,
                modifier = Modifier.background(if (m.first) MaterialTheme.colorScheme.primary else Color(0xFF1E1E1E), RoundedCornerShape(10.dp)).padding(8.dp))
        }
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(t, { t = it }, Modifier.weight(1f), placeholder = { Text("Perintah untuk asisten") }, singleLine = true)
        Button(onClick = { if (t.isNotBlank()) { ed.ask(t.trim()); t = "" } }, enabled = !ed.busy) { Text("Kirim") }
    }
}
