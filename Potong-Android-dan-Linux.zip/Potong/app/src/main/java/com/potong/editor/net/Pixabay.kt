package com.potong.editor.net

import android.net.Uri
import com.potong.editor.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class StockVideo(val id: Long, val user: String, val url: String, val seconds: Int, val page: String)

/**
 * API resmi Pixabay hanya menyediakan gambar dan video (bukan musik). Musik dibuka lewat halaman
 * Pixabay Music di browser lalu diimpor pengguna sebagai file audio.
 * Sebutkan "Sumber: Pixabay" di UI saat menampilkan hasil (syarat penggunaan API).
 */
object Pixabay {
    private val key get() = BuildConfig.PIXABAY_KEY

    suspend fun searchVideos(q: String): List<StockVideo> = withContext(Dispatchers.IO) {
        check(key.isNotBlank()) { "API key Pixabay belum diisi. Tambahkan pixabay.key=KUNCI di local.properties, lalu build ulang." }
        val enc = URLEncoder.encode(q.ifBlank { "nature" }, "UTF-8")
        val c = URL("https://pixabay.com/api/videos/?key=$key&q=$enc&per_page=10&safesearch=true")
            .openConnection() as HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 15000
        try {
            val hits = JSONObject(c.inputStream.bufferedReader().use { it.readText() }).getJSONArray("hits")
            (0 until hits.length()).mapNotNull { i ->
                val h = hits.getJSONObject(i)
                val v = h.getJSONObject("videos")
                val pick = listOf("small", "medium", "tiny").mapNotNull { v.optJSONObject(it) }
                    .firstOrNull { it.optString("url").isNotBlank() } ?: return@mapNotNull null
                StockVideo(h.getLong("id"), h.optString("user"), pick.getString("url"), h.optInt("duration"), h.optString("pageURL"))
            }
        } finally {
            c.disconnect()
        }
    }

    /** Unduh ke penyimpanan aplikasi (hotlink permanen tidak diizinkan Pixabay). */
    suspend fun download(url: String, dest: File) = withContext(Dispatchers.IO) {
        URL(url).openStream().use { i -> dest.outputStream().use { o -> i.copyTo(o) } }
    }

    fun musicPageUrl(q: String) =
        if (q.isBlank()) "https://pixabay.com/music/" else "https://pixabay.com/music/search/${Uri.encode(q)}/"
}
