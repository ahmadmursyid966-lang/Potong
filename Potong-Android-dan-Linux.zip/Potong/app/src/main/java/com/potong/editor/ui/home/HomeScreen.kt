package com.potong.editor.ui.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.potong.editor.data.Project
import com.potong.editor.data.ProjectStore
import com.potong.editor.ui.theme.Dim
import com.potong.editor.ui.theme.Panel
import java.util.UUID

private val RATIOS = listOf("9:16" to "TikTok / Reels", "16:9" to "YouTube", "1:1" to "Kotak", "4:5" to "Feed Instagram")

@Composable
fun HomeScreen(onOpen: (String) -> Unit) {
    val ctx = LocalContext.current
    val store = remember { ProjectStore(ctx) }
    var list by remember { mutableStateOf(store.list()) }
    var ask by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Potong", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
        Text("Potong, warnai, dan ekspor video di HP.", color = Dim)
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = { ask = true },
            modifier = Modifier.fillMaxWidth().height(60.dp),
            shape = RoundedCornerShape(14.dp)
        ) {
            Icon(Icons.Default.Add, null)
            Spacer(Modifier.width(8.dp))
            Text("Proyek baru", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(24.dp))
        Text("Draf", fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        if (list.isEmpty()) Text("Belum ada proyek. Tekan Proyek baru untuk mulai.", color = Dim)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list, key = { it.id }) { p ->
                Card(
                    Modifier.fillMaxWidth().clickable { onOpen(p.id) },
                    colors = CardDefaults.cardColors(containerColor = Panel)
                ) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(p.name, fontWeight = FontWeight.Bold)
                            Text("${p.clips.size} klip • ${p.ratio} • ${p.totalMs / 1000} dtk", color = Dim, fontSize = 12.sp)
                        }
                        IconButton(onClick = { store.delete(p.id); list = store.list() }) {
                            Icon(Icons.Default.Delete, "Hapus proyek")
                        }
                    }
                }
            }
        }
    }

    if (ask) AlertDialog(
        onDismissRequest = { ask = false },
        title = { Text("Pilih ukuran") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                RATIOS.forEach { (r, name) ->
                    OutlinedButton(
                        onClick = {
                            val p = Project(UUID.randomUUID().toString(), "Proyek ${list.size + 1}", r)
                            store.save(p); ask = false; onOpen(p.id)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("$r  •  $name") }
                }
            }
        },
        confirmButton = { TextButton(onClick = { ask = false }) { Text("Batal") } }
    )
}
