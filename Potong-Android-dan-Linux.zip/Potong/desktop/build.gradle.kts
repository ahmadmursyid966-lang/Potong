import org.jetbrains.compose.desktop.application.dsl.TargetFormat

plugins {
    kotlin("jvm") version "1.9.22"
    id("org.jetbrains.compose") version "1.6.0"
}
dependencies {
    implementation(compose.desktop.currentOs)
    implementation(compose.material3)
    implementation("uk.co.caprica:vlcj:4.8.2")
    implementation("org.json:json:20240303")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-swing:1.8.0")
}
compose.desktop {
    application {
        mainClass = "MainKt"
        nativeDistributions { targetFormats(TargetFormat.Deb); packageName = "potong"; packageVersion = "1.0.0" }
    }
}
