package com.potong.editor.ai

import org.json.JSONObject

/** Jembatan antara agen dan editor: agen melihat kondisi proyek lewat snapshot() dan bertindak lewat call(). */
interface ToolHost {
    fun snapshot(): JSONObject
    fun call(tool: String, args: JSONObject): String
}

const val AGENT_SYSTEM = """Kamu agen editor video. Lihat KONDISI PROYEK (JSON), lalu balas HANYA satu objek JSON:
{"say":"penjelasan singkat","calls":[{"tool":"nama","args":{}}],"done":false}
Setelah alat dijalankan kamu melihat hasilnya dan boleh lanjut. Isi "done":true bila tugas selesai. Indeks klip mulai dari 0, waktu dalam detik.
Alat: select_clip{index} | seek{sec} | split{} (di playhead) | split_at{sec} | delete_clip{index} | trim{index,start,end} (detik sumber klip) | set_speed{index,value 0.25-4} | set_volume{index,value 0-1} | set_filter{name,all} | add_text{text,start,dur} | add_3d{shape,color} | find_music{query} | find_stock{query} | undo{}
Filter: Normal, Hitam putih, Cerah, Hangat, Dingin, Drama, Pudar, Terang. Bentuk 3D: kubus, piramida, prisma, bola. Warna: merah, biru, hijau, kuning, ungu, oranye, putih, toska.
Contoh: permintaan "pisah di detik 5 lalu hitam putih" -> {"say":"Memisah lalu memberi filter","calls":[{"tool":"split_at","args":{"sec":5}},{"tool":"set_filter","args":{"name":"Hitam putih","all":false}}],"done":true}
Jika permintaan tidak bisa dilakukan, jelaskan di "say" dengan "calls":[] dan "done":true."""

/**
 * Siklus agen: lihat kondisi -> model memilih alat -> alat dijalankan -> hasil dikirim balik -> ulangi
 * sampai "done", tidak ada panggilan lagi, atau batas langkah. Semua alat divalidasi oleh editor (host).
 */
class Agent(private val engine: LlmEngine, private val host: ToolHost, private val maxSteps: Int = 6) {
    suspend fun run(user: String, onSay: (String) -> Unit) {
        val obs = StringBuilder()
        repeat(maxSteps) {
            val prompt = "<|im_start|>system\n$AGENT_SYSTEM<|im_end|>\n<|im_start|>user\n" +
                "KONDISI PROYEK:\n${host.snapshot()}\n\nPERMINTAAN: $user\n" +
                (if (obs.isNotEmpty()) "\nHASIL ALAT SEBELUMNYA:\n$obs" else "") +
                "<|im_end|>\n<|im_start|>assistant\n"
            val raw = engine.generate(prompt)
            if (raw == "__ERR_CTX__") { onSay("Proyek terlalu panjang untuk konteks model."); return }
            val j = runCatching { JSONObject(raw.substring(raw.indexOf('{'), raw.lastIndexOf('}') + 1)) }.getOrNull()
            if (j == null) { obs.append("- Balasan bukan JSON valid. Balas hanya JSON.\n"); return@repeat }
            j.optString("say").takeIf { it.isNotBlank() }?.let(onSay)
            val calls = j.optJSONArray("calls")
            val n = calls?.length() ?: 0
            for (i in 0 until n) {
                val c = calls!!.optJSONObject(i) ?: continue
                val tool = c.optString("tool")
                val res = host.call(tool, c.optJSONObject("args") ?: JSONObject())
                onSay("• $tool → $res")
                obs.append("- $tool -> $res\n")
            }
            if (n == 0 || j.optBoolean("done")) return
        }
        onSay("Batas $maxSteps langkah tercapai. Ketik lagi kalau mau dilanjutkan.")
    }
}
