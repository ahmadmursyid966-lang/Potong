package com.potong.editor.ai

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.Executors

/**
 * Mesin Qwen offline (GGUF) lewat llama.cpp (JNI). Hanya aktif kalau llama.cpp ikut dibuild
 * (lihat README); kalau tidak, nativeOk = false dan aplikasi memakai pembaca kata kunci.
 */
class LlamaEngine(private val app: Context) : LlmEngine {
    companion object {
        val nativeOk: Boolean = runCatching { System.loadLibrary("potong_llm") }.isSuccess
    }

    private val io = Executors.newSingleThreadExecutor().asCoroutineDispatcher()  // satu thread: inferensi tidak boleh paralel
    private var handle = 0L
    override val ready: Boolean get() = handle != 0L
    val modelFile: File get() = File(app.filesDir, "models/qwen.gguf")
    val hasModel: Boolean get() = modelFile.exists()

    /** Mengembalikan null kalau berhasil, atau pesan galat. */
    suspend fun load(ctxSize: Int = 2048): String? = withContext(io) {
        if (!nativeOk) return@withContext "Mesin llama.cpp belum ikut dibuild."
        if (!hasModel) return@withContext "Model belum diimpor."
        if (handle != 0L) return@withContext null
        val threads = (Runtime.getRuntime().availableProcessors() - 2).coerceIn(2, 6)
        handle = runCatching { nativeLoad(modelFile.absolutePath, ctxSize, threads) }.getOrDefault(0L)
        if (handle == 0L) "Gagal memuat model (RAM kurang atau file bukan GGUF)." else null
    }

    override suspend fun generate(prompt: String): String = withContext(io) {
        check(handle != 0L) { "Model belum dimuat" }
        String(nativeGenerate(handle, prompt, 384, 0.2f), Charsets.UTF_8)
    }

    fun unload() { val h = handle; handle = 0L; if (h != 0L) runCatching { nativeFree(h) } }

    suspend fun importModel(u: Uri): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            unload()
            val dir = modelFile.parentFile!!.apply { mkdirs() }
            val tmp = File(dir, "qwen.part")
            app.contentResolver.openInputStream(u)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o, 1 shl 20) } }
            tmp.renameTo(modelFile)
        }.getOrDefault(false)
    }

    private external fun nativeLoad(path: String, nCtx: Int, threads: Int): Long
    private external fun nativeGenerate(h: Long, prompt: String, maxNew: Int, temp: Float): ByteArray
    private external fun nativeFree(h: Long)
}
