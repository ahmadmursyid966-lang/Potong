@file:OptIn(ExperimentalMaterial3Api::class, UnstableApi::class)

package com.potong.editor.ui.editor

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.PlayerView
import com.potong.editor.data.COLORS
import com.potong.editor.data.FILTERS
import com.potong.editor.data.SHAPES
import com.potong.editor.ui.studio3d.Scene3DView
import com.potong.editor.ui.theme.Accent
import com.potong.editor.ui.theme.Bg
import com.potong.editor.ui.theme.Dim
import com.potong.editor.ui.theme.Panel
import kotlinx.coroutines.delay

private fun fmt(ms: Long) = "%d:%02d".format(ms / 60000, ms / 1000 % 60)
private val TABS = listOf("Klip", "Teks", "3D", "Audio", "Stok", "AI")

@Composable
fun EditorScreen(id: String, onBack: () -> Unit, vm: EditorViewModel = viewModel()) {
    LaunchedEffect(id) { vm.load(id) }
    val ctx = LocalContext.current
    val p = vm.project
    var tab by remember { mutableIntStateOf(0) }
    var pos by remember { mutableLongStateOf(0L) }
    var playing by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { while (true) { pos = vm.globalPos(); playing = vm.player.isPlaying; delay(100) } }

    val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()) { vm.addClips(it) }
    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) {
            runCatching { ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            vm.setMusic(u)
        }
    }

    val pickModel = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.importModel(u) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(p.name, maxLines = 1) },
                navigationIcon = { TextButton(onClick = onBack) { Text("←", fontSize = 20.sp) } },
                actions = {
                    TextButton(onClick = { vm.undo() }) { Text("Urung") }
                    TextButton(onClick = { vm.redo() }) { Text("Ulang") }
                    Button(onClick = { vm.export() }, enabled = !vm.busy && p.clips.isNotEmpty()) { Text("Ekspor") }
                    Spacer(Modifier.width(8.dp))
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Panel, titleContentColor = Color.White)
            )
        },
        containerColor = Bg
    ) { pad ->
        Column(Modifier.padding(pad).imePadding()) {
            if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            // ---- preview ----
            Box(Modifier.fillMaxWidth().weight(1f).background(Color.Black), contentAlignment = Alignment.Center) {
                Box(Modifier.fillMaxHeight().aspectRatio(p.aspect, matchHeightConstraintsFirst = true)) {
                    AndroidView(factory = { c -> PlayerView(c).apply { useController = false; player = vm.player } }, modifier = Modifier.fillMaxSize())
                    if (p.objs.isNotEmpty()) Scene3DView(p.objs, Modifier.fillMaxSize())
                    Column(Modifier.align(Alignment.BottomCenter).padding(24.dp)) {
                        p.texts.filter { pos in it.startMs..it.endMs }.forEach {
                            Text(it.text, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            // ---- transport ----
            Row(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { vm.togglePlay() }) { Text(if (playing) "⏸" else "▶", fontSize = 20.sp) }
                Slider(
                    value = pos.coerceIn(0L, maxOf(p.totalMs, 1L)).toFloat(), onValueChange = { vm.seekGlobal(it.toLong()) },
                    valueRange = 0f..maxOf(p.totalMs, 1L).toFloat(), modifier = Modifier.weight(1f)
                )
                Text("${fmt(pos)} / ${fmt(p.totalMs)}", color = Dim, fontSize = 12.sp)
            }
            // ---- timeline ----
            LazyRow(Modifier.fillMaxWidth().background(Bg).padding(8.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                itemsIndexed(p.clips) { i, c ->
                    Box(
                        Modifier.width((c.durationMs / 40).dp.coerceAtLeast(56.dp)).height(44.dp)
                            .background(if (i == vm.sel) Accent else Panel, RoundedCornerShape(6.dp))
                            .clickable { vm.selectClip(i) }.padding(6.dp)
                    ) {
                        Text("${i + 1} · ${fmt(c.durationMs)}${if (c.speed != 1f) " · ${c.speed}x" else ""}", fontSize = 11.sp,
                            color = if (i == vm.sel) Color.Black else Color.White)
                    }
                }
            }
            ScrollableTabRow(selectedTabIndex = tab, containerColor = Panel, edgePadding = 8.dp) {
                TABS.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) }
            }
            // ---- panel ----
            Column(Modifier.fillMaxWidth().height(250.dp).background(Panel).padding(12.dp)) {
                vm.note?.let { n ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(n, color = Accent, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        TextButton(onClick = { vm.note = null }) { Text("OK") }
                    }
                }
                when (tab) {
                    0 -> ClipPanel(vm) { pickVideo.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) }
                    1 -> TextPanel(vm)
                    2 -> ObjPanel(vm)
                    3 -> AudioPanel(vm) { pickAudio.launch(arrayOf("audio/*")) }
                    4 -> StockPanel(vm)
                    else -> AiPanel(vm) { pickModel.launch(arrayOf("*/*")) }
                }
            }
        }
    }
}

@Composable
private fun ClipPanel(vm: EditorViewModel, onAdd: () -> Unit) {
    val c = vm.project.clips.getOrNull(vm.sel)
    Column(Modifier.verticalScroll(rememberScrollState())) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onAdd) { Text("+ Video") }
            OutlinedButton(onClick = { vm.split() }) { Text("Pisah") }
            OutlinedButton(onClick = { vm.deleteSel() }) { Text("Hapus") }
        }
        if (c == null) { Text("Tambahkan video dulu.", color = Dim); return }
        var sp by remember(vm.sel, c.speed) { mutableFloatStateOf(c.speed) }
        var vo by remember(vm.sel, c.volume) { mutableFloatStateOf(c.volume) }
        Text("Kecepatan ${"%.2f".format(sp)}x (preview)", color = Dim, fontSize = 12.sp)
        Slider(sp, { sp = it }, valueRange = 0.25f..4f, onValueChangeFinished = { vm.setSpeed(sp) })
        Text("Volume ${(vo * 100).toInt()}%", color = Dim, fontSize = 12.sp)
        Slider(vo, { vo = it }, valueRange = 0f..1f, onValueChangeFinished = { vm.setVolume(vo) })
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            itemsIndexed(FILTERS) { _, f -> FilterChip(selected = c.filter == f, onClick = { vm.setFilter(f) }, label = { Text(f) }) }
        }
        TextButton(onClick = { vm.setFilter(c.filter, true) }) { Text("Terapkan filter ke semua klip") }
    }
}

@Composable
private fun TextPanel(vm: EditorViewModel) {
    var t by remember { mutableStateOf("") }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(t, { t = it }, Modifier.weight(1f), placeholder = { Text("Isi teks") }, singleLine = true)
        Button(onClick = { if (t.isNotBlank()) { vm.addText(t.trim()); t = "" } }) { Text("Tambah") }
    }
    Text("Teks tampil 3 detik dari posisi playhead.", color = Dim, fontSize = 12.sp)
    LazyColumn { itemsIndexed(vm.project.texts) { i, x ->
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("${fmt(x.startMs)}  ${x.text}", Modifier.weight(1f))
            IconButton(onClick = { vm.removeText(i) }) { Icon(Icons.Filled.Delete, "Hapus") }
        }
    } }
}

@Composable
private fun ObjPanel(vm: EditorViewModel) {
    var shape by remember { mutableStateOf(SHAPES.first()) }
    var color by remember { mutableLongStateOf(COLORS.values.first()) }
    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        itemsIndexed(SHAPES) { _, s -> FilterChip(selected = shape == s, onClick = { shape = s }, label = { Text(s) }) }
    }
    Spacer(Modifier.height(6.dp))
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        itemsIndexed(COLORS.entries.toList()) { _, e ->
            Box(Modifier.size(32.dp).background(Color(e.value), RoundedCornerShape(16.dp)).clickable { color = e.value })
        }
    }
    Button(onClick = { vm.addObj(shape, color) }, modifier = Modifier.padding(top = 8.dp)) { Text("Tambah objek 3D") }
    LazyColumn { itemsIndexed(vm.project.objs) { i, o ->
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(o.shape, Modifier.weight(1f))
            IconButton(onClick = { vm.removeObj(i) }) { Icon(Icons.Filled.Delete, "Hapus") }
        }
    } }
}

@Composable
private fun AudioPanel(vm: EditorViewModel, onImport: () -> Unit) {
    var q by remember { mutableStateOf("") }
    val m = vm.project.music
    Column(Modifier.verticalScroll(rememberScrollState())) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(q, { q = it }, Modifier.weight(1f), placeholder = { Text("mis. santai, ceria") }, singleLine = true)
            Button(onClick = { vm.openMusicPage(q) }) { Text("Cari di Pixabay") }
        }
        Text("Pixabay tidak punya API audio: halaman terbuka di browser. Unduh lagunya, lalu impor.", color = Dim, fontSize = 12.sp)
        OutlinedButton(onClick = onImport) { Text("Impor musik") }
        if (m != null) {
            var v by remember(m.uri, m.volume) { mutableFloatStateOf(m.volume) }
            Text(m.name, maxLines = 1)
            Slider(v, { v = it }, valueRange = 0f..1f, onValueChangeFinished = { vm.setMusicVolume(v) })
            TextButton(onClick = { vm.clearMusic() }) { Text("Hapus musik") }
        }
    }
}

@Composable
private fun StockPanel(vm: EditorViewModel) {
    var q by remember { mutableStateOf("") }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(q, { q = it }, Modifier.weight(1f), placeholder = { Text("mis. pantai") }, singleLine = true)
        Button(onClick = { vm.searchStock(q) }, enabled = !vm.busy) { Text("Cari") }
    }
    Text("Sumber: Pixabay (butuh kunci API di local.properties)", color = Dim, fontSize = 12.sp)
    LazyColumn { itemsIndexed(vm.stock) { _, v ->
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("${v.user} · ${v.seconds}s", Modifier.weight(1f))
            TextButton(onClick = { vm.addStock(v) }, enabled = !vm.busy) { Text("Tambah") }
        }
    } }
}

@Composable
private fun ColumnScope.AiPanel(vm: EditorViewModel, onPickModel: () -> Unit) {
    var t by remember { mutableStateOf("") }
    Row(verticalAlignment = Alignment.CenterVertically) {
        val st = vm.modelMsg ?: when {
            !com.potong.editor.ai.LlamaEngine.nativeOk -> "Mode kata kunci (mesin Qwen belum ikut dibuild)"
            !vm.llama.hasModel -> "Model Qwen belum diimpor"
            vm.llama.ready -> "Agen Qwen aktif (offline)"
            else -> "Model terpasang, dimuat saat perintah pertama"
        }
        Text(st, color = Dim, fontSize = 11.sp, modifier = Modifier.weight(1f))
        if (com.potong.editor.ai.LlamaEngine.nativeOk) TextButton(onClick = onPickModel, enabled = !vm.busy) { Text("Impor .gguf") }
    }
    val ls = rememberLazyListState()
    LaunchedEffect(vm.chat.size) { if (vm.chat.isNotEmpty()) ls.animateScrollToItem(vm.chat.lastIndex) }
    LazyColumn(Modifier.weight(1f), ls, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        itemsIndexed(vm.chat) { _, m ->
            Text(m.text, fontSize = 13.sp, color = if (m.user) Color.Black else Color.White,
                modifier = Modifier.background(if (m.user) Accent else Bg, RoundedCornerShape(10.dp)).padding(8.dp))
        }
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(t, { t = it }, Modifier.weight(1f), placeholder = { Text("Perintah untuk asisten") }, singleLine = true)
        Button(onClick = { if (t.isNotBlank()) { vm.ask(t.trim()); t = "" } }) { Text("Kirim") }
    }
}
