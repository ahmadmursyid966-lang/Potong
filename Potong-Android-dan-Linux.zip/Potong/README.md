# Potong - editor video Android (Kotlin + Compose + Media3)
1. Buka folder ini di Android Studio (Hedgehog/Iguana atau lebih baru, JDK 17), tunggu Gradle sync.
2. (Opsional, untuk video stok) buat local.properties dan isi: pixabay.key=KUNCI_KAMU  (lihat local.properties.example).
3. Run di HP/emulator (Android 8.0+).
Musik: API Pixabay tidak punya audio, jadi tombol "Cari musik" membuka halaman Pixabay Music di browser. Unduh lagunya lalu impor di tab Audio.

## Agen AI Qwen offline (opsional)
Tanpa langkah ini aplikasi tetap jalan memakai pembaca kata kunci. Untuk agen Qwen:
1. Android Studio > SDK Manager > SDK Tools: pasang NDK dan CMake 3.22.1.
2. Taruh llama.cpp di app/src/main/cpp/llama.cpp, mis. `git clone https://github.com/ggml-org/llama.cpp app/src/main/cpp/llama.cpp` (pakai rilis/tag stabil).
3. Sync Gradle. Native hanya dibuild kalau folder itu ada. Build pertama lama.
4. Unduh model GGUF Qwen2.5 Instruct (disarankan 1.5B Q4_K_M, sekitar 1 GB) dari Hugging Face ke HP, lalu tab AI > Impor .gguf. Cek lisensi tiap ukuran model.
5. `llama_jni.cpp` ditulis untuk API llama.cpp 2025 dan belum diuji. Kalau ada error nama fungsi, samakan dengan examples/simple/simple.cpp di versi yang dipakai.

## Build tanpa Android Studio (GitHub Actions)
1. Buat repositori GitHub, upload ISI folder ini (settings.gradle.kts harus di akar repo, termasuk folder .github).
2. Tab Actions > "Build APK" > Run workflow (centang with_qwen kalau mau mesin Qwen).
3. Setelah hijau, buka run-nya > Artifacts > Potong-debug-apk, unduh, ekstrak, pasang app-debug.apk di HP (izinkan instal dari sumber tidak dikenal).
Opsional: Settings > Secrets > tambah PIXABAY_KEY untuk video stok.
