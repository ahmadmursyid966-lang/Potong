// Jembatan JNI minimal ke llama.cpp. Ditulis untuk API llama.cpp 2025 (sampler chain, llama_vocab).
// BELUM DIUJI. Kalau compiler protes nama fungsi (API llama.cpp sering berubah), samakan dengan
// llama.cpp/examples/simple/simple.cpp pada versi yang kamu pakai.
#include <jni.h>
#include <string>
#include <vector>
#include "llama.h"

struct Ctx { llama_model* model; llama_context* ctx; const llama_vocab* vocab; };

extern "C" JNIEXPORT jlong JNICALL
Java_com_potong_editor_ai_LlamaEngine_nativeLoad(JNIEnv* env, jobject, jstring path, jint nCtx, jint threads) {
    const char* p = env->GetStringUTFChars(path, nullptr);
    llama_backend_init();
    llama_model_params mp = llama_model_default_params();
    llama_model* m = llama_model_load_from_file(p, mp);
    env->ReleaseStringUTFChars(path, p);
    if (!m) return 0;
    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = nCtx; cp.n_batch = nCtx; cp.n_threads = threads; cp.n_threads_batch = threads;
    llama_context* c = llama_init_from_model(m, cp);
    if (!c) { llama_model_free(m); return 0; }
    return (jlong) new Ctx{m, c, llama_model_get_vocab(m)};
}

extern "C" JNIEXPORT jbyteArray JNICALL
Java_com_potong_editor_ai_LlamaEngine_nativeGenerate(JNIEnv* env, jobject, jlong h, jstring prompt, jint maxNew, jfloat temp) {
    auto* s = (Ctx*) h;
    const char* pc = env->GetStringUTFChars(prompt, nullptr);
    std::string text(pc);
    env->ReleaseStringUTFChars(prompt, pc);
    auto ret = [&](const std::string& o) {
        jbyteArray a = env->NewByteArray((jsize) o.size());
        env->SetByteArrayRegion(a, 0, (jsize) o.size(), (const jbyte*) o.data());
        return a;
    };
    llama_memory_clear(llama_get_memory(s->ctx), true);   // versi lama: llama_kv_cache_clear(s->ctx)
    int n = -llama_tokenize(s->vocab, text.c_str(), (int) text.size(), nullptr, 0, true, true);
    if (n <= 0) return ret("");
    if (n + maxNew > (int) llama_n_ctx(s->ctx)) return ret("__ERR_CTX__");
    std::vector<llama_token> toks(n);
    if (llama_tokenize(s->vocab, text.c_str(), (int) text.size(), toks.data(), n, true, true) < 0) return ret("");

    llama_sampler* sm = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(sm, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(sm, llama_sampler_init_top_p(0.9f, 1));
    llama_sampler_chain_add(sm, llama_sampler_init_temp(temp));
    llama_sampler_chain_add(sm, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    std::string out;
    llama_token tok = 0;
    llama_batch b = llama_batch_get_one(toks.data(), (int) toks.size());
    for (int i = 0; i < maxNew; i++) {
        if (llama_decode(s->ctx, b) != 0) break;
        tok = llama_sampler_sample(sm, s->ctx, -1);
        if (llama_vocab_is_eog(s->vocab, tok)) break;
        char buf[256];
        int k = llama_token_to_piece(s->vocab, tok, buf, sizeof(buf), 0, true);
        if (k < 0) break;
        out.append(buf, k);
        b = llama_batch_get_one(&tok, 1);
    }
    llama_sampler_free(sm);
    return ret(out);
}

extern "C" JNIEXPORT void JNICALL
Java_com_potong_editor_ai_LlamaEngine_nativeFree(JNIEnv*, jobject, jlong h) {
    auto* s = (Ctx*) h;
    llama_free(s->ctx);
    llama_model_free(s->model);
    delete s;
}
