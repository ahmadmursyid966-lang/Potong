import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Kunci API Pixabay (opsional, untuk video stok) dibaca dari local.properties: pixabay.key=KUNCI_KAMU
val localProps = Properties().apply {
    rootProject.file("local.properties").takeIf { it.exists() }?.inputStream()?.use { load(it) }
}

// Mesin Qwen offline aktif otomatis kalau folder llama.cpp ada (lihat README).
val hasLlama = file("src/main/cpp/llama.cpp/CMakeLists.txt").exists()

android {
    namespace = "com.potong.editor"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.potong.editor"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "0.3.0"
        if (hasLlama) {
            ndk { abiFilters += "arm64-v8a" }
            externalNativeBuild { cmake { cppFlags += "-std=c++17"; arguments += listOf("-DANDROID_STL=c++_shared") } }
        }
        buildConfigField("String", "PIXABAY_KEY", "\"${localProps.getProperty("pixabay.key", "")}\"")
    }
    if (hasLlama) {
        externalNativeBuild { cmake { path = file("src/main/cpp/CMakeLists.txt"); version = "3.22.1" } }
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true; buildConfig = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.8" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.7.0")
    implementation("androidx.activity:activity-compose:1.8.2")
    implementation("androidx.navigation:navigation-compose:2.7.7")
    implementation(platform("androidx.compose:compose-bom:2024.02.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.media3:media3-common:1.2.1")
    implementation("androidx.media3:media3-exoplayer:1.2.1")
    implementation("androidx.media3:media3-ui:1.2.1")
    implementation("androidx.media3:media3-effect:1.2.1")
    implementation("androidx.media3:media3-transformer:1.2.1")
}
